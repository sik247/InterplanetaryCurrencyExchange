
public interface Exchangeable {
	
	final double EXCHANGE_RATE_ED = 1.00 ;
	final double EXCHANGE_RATE_MM = 1.30  ;
	final double EXCHANGE_RATE_SS = 0.87 ;
	final double EXCHANGE_RATE_NN = 2.00  ;
	
	public void exchange (Currency other, double amount) ; 
}
