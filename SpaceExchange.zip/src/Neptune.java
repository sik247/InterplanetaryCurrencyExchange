public class Neptune extends Currency implements Exchangeable {
	public Neptune (double totalFunds) {
		this.planetName = "Neptune";
		this.currencyName ="Neptune Nuggets";
		this.totalFunds = totalFunds; //Instantiate object from mars class, access property, this. is  needed. 

	}
	
	
	
		
	public double toEarthDollars(double amount) { 
		this.totalFunds = this.totalFunds - amount;
		double EarthDollars = amount / EXCHANGE_RATE_NN; 
		return  EarthDollars; 
		
		
	}
	public double fromEarthDollars(double EarthDollars) { //usd to mars adding to total funds
		
		double amount = EarthDollars * EXCHANGE_RATE_NN; 
		this.totalFunds = totalFunds + amount; 
		return totalFunds; 
		
		
		
	}
	public void exchange (Currency other, double amount) { 
		//1. currency type 2. amount detect currecy & exchange
		
		if (amount > this.totalFunds) {
			System.out.printf("Uh oh  - %s only has an available balance of $%.2f which is less than $%.2f \n\n" , this.planetName, this.totalFunds, amount);		} 
		else { 
			double earthDollars = this.toEarthDollars(amount); //mars -> USD
			//other.fromEarthDollars(earthDollars);
			 //other planet -> USD (jupiter(other).fromEArthDollars )
			System.out.println("Converting from " + this.currencyName + " to " +  other.currencyName + " and initiating..." );
			System.out.printf("$%.2f %s = $ %.2f EarthDollars = %s %.2f \n", amount, this.currencyName, earthDollars ,other.currencyName, other.fromEarthDollars(earthDollars));
			System.out.printf("Neptune has a total of $ %.2f %s \n%s has a total of $ %.2f %s \n\n" , this.totalFunds, this.currencyName, other.planetName, other.totalFunds, other.currencyName);

		
		}
		
		
}
	
		
	
}
	
